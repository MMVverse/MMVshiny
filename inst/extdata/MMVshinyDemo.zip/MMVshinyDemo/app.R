# MMVshiny Demo App -----------------------------------------------------------
# A minimal Shiny app demonstrating how to use MMVshiny:
# - load a parameter specification from Excel
# - generate browser-side JS event handlers
# - generate R scripts for reactives / observers / status icon rendering
# - initialize one MMVshiny state object 
# - let the server function process GUI events and render outputs

rm(list = ls(all.names = TRUE))

library(shiny)
library(shinyjs)
library(DT)
library(data.table)
library(xlsx)   # used by MMVshiny::LoadStateSpecification
library(MMVshiny)

source("Resources/FUNCTION_RunSimulation.R")

options("MMVshiny.verbose" = FALSE)

# LOAD INPUT SPEC -------------------------------------------------------------
stateSpec <- MMVshiny::LoadStateSpecification(
  filename = "Resources/MMVshinyDemoParameters.xlsx"
)

# GENERATE SCRIPTS -------------------------------------------------------------

# Create output folders for generated scripts ----------------------
if(dir.exists("www/Generated")) {
  unlink("www/Generated", recursive = TRUE)
}
if(dir.exists("Resources/Generated")) {
  unlink("Resources/Generated", recursive = TRUE)
}
dir.create("Resources/Generated", recursive = TRUE)
dir.create("www/Generated", recursive = TRUE)

# . Generate scripts creating observeEvent code to be sourced from each newly created state environment ----

# . . Generate reactive getters (Compound(), Weight_kg(), ...) inside each state ----
scriptCreateReactivesInState.R <- MMVshiny::GenerateScriptCreatingReactives(
  stateSpec,
  # Object name pointing to the state environment, which lives in the state 
  # environment itself (i.e. 'this' object in the generated script will refer to the state environment). 
  # This is used to generate code like MYSTATE$Compound().
  stateObjectName = "MYSTATE", 
  filename = "Resources/Generated/CreateReactivesInState.R"
)
# . . Generate observers to reset-events re-initializing all input parameters in the state ----
# to their default values. This generated script is necessary even if there is no Reset button in the UI, 
# because the initial initialization of all inputs is done by handling a Reset event.
# In addition to these observers in the state, the server function will also need an observer to "displayed" events, 
# which will update the GUI values and colors when the state changes (e.g. after processing user input or after a reset). 
# This is generated in scriptObserveEventsInServer.R (see below). 
scriptObserveResetCountInState.R <- MMVshiny::GenerateScriptCreatingObservers(
  stateSpec,
  stateObjectName = "MYSTATE", 
  observerTypes = c("resetCount"),
  filename = "Resources/Generated/ObserveResetCountInState.R")

# Only for IDs having reactive VALEXPR in the parameter spec
scriptObserveDefaultInState.R <- MMVshiny::GenerateScriptCreatingObservers(
  stateSpec,
  stateObjectName = "MYSTATE", 
  observerTypes = c("default"),
  ids = c("Regimen"), 
  filename = "Resources/Generated/ObserveDefaultInState.R")

# Source into each newly created state
scriptsToSourceInState <- c(scriptCreateReactivesInState.R, 
                            scriptObserveResetCountInState.R, 
                            scriptObserveDefaultInState.R)

# . Generate observers to run in the server function ----

# . . Generate a script with observers to handle user input events (i.e. changes in input$count<ID>) ----
# - on user interaction, call ProcessGuiInputEvent
# - on displayed changes, update GUI values and colors
scriptObserveEventsInServer.R <- MMVshiny::GenerateScriptCreatingObservers(
  stateSpec,
  stateObjectName = "state", # This is how the state object will be called in the server function
  observerTypes = c("countID", "displayed"),
  filename = "Resources/Generated/ObserveEventsInServer.R"
)

# . . Generate renderUI calls for status icons ----
scriptRenderStatusIcons.R <- MMVshiny::GenerateScriptRenderingIcons(
  stateSpec,
  prefixGuiId = "",
  stateObjectName = "state", # This is how the state object will be called in the server function
  filename = "Resources/Generated/RenderStatusIcons.R"
)

# UI --------------------------------------------------------------------------

# . Generate client-side JS handlers  ----
# These event handlers are triggered when the user presses Enter or clicks outside of a 
# text field after editing it.
# They will increment input$count<ID> when a GUI element has changed. 
# The observer in scriptObserveEventsInServer.R will react to this change and call ProcessGuiInputEvent, 
# which will update the state and trigger all the necessary updates (including displayed changes, 
# which will be handled by another observer created in scriptObserveEventsInServer.R)
# This has to be included in the UI via includeScript (see ui definition below).
scriptHandleEvents.js <- MMVshiny::GenerateJavaScriptEventHandlers(
  stateSpec,
  filename = "www/Generated/HandleEvents.js"
)


# JS helpers used by MMVshiny to change background and font colors of GUI elements ---- 
# Used by MMVshiny when the 'displayed' value or the source for an input changes 
# (e.g. to highlight the source of an input value. 
# This code needs to be included in the UI, via extendShinyjs (see ui-definition below)
jsCode <- 'shinyjs.backgroundCol = function(params){
var defaultParams = { id : null, col : "red" };
params = shinyjs.getParams(params, defaultParams);
var el = $("#" + params.id);
el.css("background-color", params.col);
}
shinyjs.fontCol = function(params){
var defaultParams = { id : null, col : "red" };
params = shinyjs.getParams(params, defaultParams);
var el = $("#" + params.id);
el.css("color", params.col);
}'

ui <- fluidPage(
  includeScript(scriptHandleEvents.js),
  tags$head(
    shinyjs::useShinyjs(),
    extendShinyjs(text = jsCode, functions = c("backgroundCol", "fontCol")),
    tags$style(
      HTML(
        ".mmv-box { padding: 12px; border: 1px solid #ddd; border-radius: 6px; background: #fafafa; }"
      )
    )
  ),

  titlePanel("MMVshiny Demo"),

  fluidRow(
    column(
      width = 4,
      div(
        class = "mmv-box",
        tags$table(
          tags$tr(MMVshiny::CreateUIInput(spec = stateSpec, id = "Compound", useLabel = TRUE)),
          tags$tr(MMVshiny::CreateUIInput(spec = stateSpec, id = "Weight_kg", useLabel = TRUE)),
          tags$tr(MMVshiny::CreateUIInput(spec = stateSpec, id = "Height_cm", useLabel = TRUE)),
          tags$tr(MMVshiny::CreateUIInput(spec = stateSpec, id = "Regimen", useLabel = TRUE)),
          tags$tr(MMVshiny::CreateUIInput(spec = stateSpec, id = "ShowCurve", useLabel = TRUE))
        ),

        tags$hr(),
        MMVshiny::CreateUIInput(spec = stateSpec, id = "RunSim"),
        tags$small("Tip: edit a field and press Enter (or click outside) to submit.")
      )
    ),

    column(
      width = 8,
      tabsetPanel(
        tabPanel(
          "Results",
          tags$br(),
          verbatimTextOutput("summary"),
          plotOutput("plot", height = 300)
        ),
        tabPanel(
          "State",
          tags$br(),
          DTOutput("tbl_state")
        ),
        tabPanel(
          "Simulation data",
          tags$br(),
          DTOutput("tbl_sim")
        )
      )
    )
  )
)

# SERVER ----------------------------------------------------------------------
server <- function(input, output, session) {

  # Initialize state (same pattern as MMVSola/MMVFree)
  state <- MMVshiny::InitState(
    stateSpec,
    listObjects = list(
      prefixGuiId = "",                   # GUI ids are the raw spec IDs
      result = shiny::reactiveVal(NULL),
      lastSummary = shiny::reactiveVal(NULL)
    ),
    scriptsToSource = scriptsToSourceInState
  )

  # Render status icons (only for rows where STATUSICON == TRUE)
  source(scriptRenderStatusIcons.R, local = TRUE)

  # Wire user input change events and displayed->GUI updates
  source(scriptObserveEventsInServer.R, local = TRUE)

  # Summary output ----
  output$summary <- renderText({
    # This is updated in the state when the user clicks "Run simulation" and the simulation is run (see Resources/MMVshinyDemoParameters.xlsx, 
    # column "ACTIONEXPR" for the RunSim row)
    s <- state$lastSummary()
    if(is.null(s)) {
      return("Click 'Run simulation' to generate results.")
    }
    paste0(
      "Compound: ", state$Compound(), "\n",
      "Regimen: ", s$regimen, "\n",
      "BMI: ", round(s$bmi, 1), "\n",
      "Suggested daily dose (toy): ", s$dose_mg, " mg"
    )
  })

  # Simulation plot ----
  output$plot <- renderPlot({
    # This is updated in the state when the user clicks "Run simulation" and the simulation is run (see Resources/MMVshinyDemoParameters.xlsx,
    # column "ACTIONEXPR" for the RunSim row)
    res <- state$result()
    if(is.null(res) || nrow(res) == 0) return(NULL)
    if(!isTRUE(state$ShowCurve())) {
      plot.new()
      text(0.5, 0.5, "Curve hidden\n(check 'Show concentration curve' to display)", cex = 1.2)
      return(invisible(NULL))
    }
    plot(res$time_h, res$conc, type = "l", xlab = "Time (h)", ylab = "Concentration (a.u.)")
  })

  # State table ----
  output$tbl_state <- renderDT({
    ids <- state$spec[TYPE %in% c("numeric input", "text input", "radio input", "select input", "checkbox input"), ID]
    dt <- data.table(
      ID = ids,
      type = state$spec[match(ids, ID), TYPE],
      default = sapply(ids, function(id) state %>% MMVshiny::GetDefault(id)),
      validated = sapply(ids, function(id) state %>% MMVshiny::GetValidated(id)),
      value =  sapply(ids, function(id) state %>% MMVshiny::Get(id)),
      displayed = sapply(ids, function(id) state %>% MMVshiny::GetDisplayed(id)),
      source = sapply(ids, function(id) state %>% MMVshiny::GetSource(id))
    )
    DT::datatable(dt, options = list(pageLength = 10), rownames = FALSE)
  })

  # Simulation table ----
  output$tbl_sim <- renderDT({
    
    # This is updated in the state when the user clicks "Run simulation" and the simulation is run (see Resources/MMVshinyDemoParameters.xlsx, 
    # column "ACTIONEXPR" for the RunSim row)
    res <- state$result()
    if(is.null(res)) {
      res <- data.table(time_h = numeric(0), conc = numeric(0))
    }
    DT::datatable(res, options = list(pageLength = 10), rownames = FALSE)
  })
}

shinyApp(ui, server)
