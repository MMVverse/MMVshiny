RunSimulation <- function(state, input, output, session) {
  # Simple 1-compartment toy simulation just for demo purposes.
  w <- state$Weight_kg()
  h <- state$Height_cm()
  regimen <- state$Regimen()
  
  # BMI
  bmi <- w / ( (h/100)^2 )
  
  freq <- ifelse(regimen == "Twice daily", 2, 1)
  dose_mg <- round(w * 10 * freq, 1)
  
  t <- seq(0, 24, by = 0.5)
  k <- 0.15
  conc <- dose_mg/100 * exp(-k*t)
  
  res <- data.table::data.table(
    time_h = t,
    conc = conc
  )
  
  state$result(res)
  state$lastSummary(list(bmi = bmi, dose_mg = dose_mg, regimen = regimen))
}